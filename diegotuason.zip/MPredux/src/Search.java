

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Image;

/**
 * Servlet implementation class Search
 */
@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		
				String search = request.getParameter("search");
				request.getSession().setAttribute("sres",null);
				List<Image> mypics = (List<Image>) request.getSession().getAttribute("mypics");
				List<Image> sres = new ArrayList();
				//try{
					for(int i=0;i<mypics.size();i++){
						String tags = mypics.get(i).getTags();
						if(tags!=null){	
							String[] taglist = tags.split(","); 
							for(int j=0;j<taglist.length;j++){
								if(taglist[j].toLowerCase()==search.toLowerCase()){
									Image temp = new Image(mypics.get(i).getName(),tags,false);
									sres.add(temp);
								}
							}
						}
					}
					
					request.getSession().setAttribute("sres",sres);
					request.getRequestDispatcher("SearchRes.jsp").forward(request, response);
				//}
				//catch(Exception e){
				//	e.printStackTrace();
				//}
				
	}

}
