

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Image;

/**
 * Servlet implementation class ImgOptions
 */
@WebServlet("/ImgOptions")
public class ImgOptions extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImgOptions() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub\


		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<Image> myimgs = (List<Image>) request.getSession().getAttribute("mypics");
		Image img = (Image) request.getSession().getAttribute("tagimg");
		String tags = request.getParameter("csv");
		//Boolean privacy = false;
		//if(request.getParameter("privacy")!=null)	privacy = true;
		
		//img.setPrivacy(privacy);
		img.setTags(tags);
		
		myimgs.add(img);
		request.getSession().setAttribute("mypics", myimgs);
		request.getSession().setAttribute("tagimg", null);
		response.sendRedirect("Pics.jsp");
	}

}
