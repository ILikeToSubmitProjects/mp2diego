

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;


import beans.Image;



/**
 * Servlet implementation class GetMyPics
 */
@WebServlet("/GetMyPics")
public class GetMyPics extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetMyPics() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<String> urls = new ArrayList();
		List<Image> imgs = new ArrayList();
		
		String path = request.getServletContext().getRealPath(request.getSession().getAttribute("uname").toString());   
		File dir = new File(path);  
		File[] list = dir.listFiles();
		Cookie[] cookies = request.getCookies();
		String un = null;
			
		for(int i=0;i<list.length;i++){  
			Image temp = new Image(list[i].getName(),"sample",false);
			imgs.add(temp);
				
		}  
		request.getSession().setAttribute("mypics", imgs);		
		
		if(cookies!=null){
			for(int i = 0; i < cookies.length; i++){
				Cookie currentCookie = cookies[i];
				if(currentCookie.getName().equals("uname")){
					un = currentCookie.getValue();
					currentCookie.setMaxAge(60*60*24*365*2);
					currentCookie.setHttpOnly(true);
					response.addCookie(currentCookie);
				}
			}
		}
		if(un !=null){
			request.getSession().setAttribute("uname", un);
			request.getRequestDispatcher("Pics.jsp")
					.forward(request, response);
		}else{
			response.sendRedirect("index.html");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		/*HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		 if (session.getAttribute("uname") == null) 
		 {
		   request.getRequestDispatcher("Pics.jsp");
		   for(int i=0; i<n;i++){
			   out.println("<img src="++"></img>");
		   }
		 }
		 else 
		 {
		     out.println("<%@include file=\"shoppingBasket.jsp\"%>");

		 }*/
		
		//
		


	}
}
