

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Image;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String un = request.getParameter("uname"); 
		String pw = request.getParameter("pword"); 
		
		
		if(un.equals("diego") && pw.equals("1234")){
			request.getSession().setAttribute("uname", un);
			request.getSession().setAttribute("fname", "Diego");
			request.getSession().setAttribute("lname", "Tuason");
			request.getSession().setAttribute("email", "diego_tuason@dlsu.edu.ph");
			request.getSession().setAttribute("imgpath","\\"+un+"\\");
			
			/*List<String> urls = new ArrayList();  
			String path = "C:\\Users\\User\\workspace\\MPredux\\WebContent\\";
			File dir = new File(path+request.getSession().getAttribute("uname"));  
			File[] list = dir.listFiles();
			//
			for(File item:list){  
			  String filename = item.getName();  

			  // add this images name to the list we are building up  
			  urls.add(filename);  

			} 
			request.setAttribute("mypics", urls);*/
			Cookie cookie = new Cookie("uname", un);
			cookie.setMaxAge(60*60*24*365*2);
			response.addCookie(cookie);
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}else if(un.equals("dlsu") && pw.equals("animo")){
			request.getSession().setAttribute("uname", un);
			request.getSession().setAttribute("fname", "Jose");
			request.getSession().setAttribute("lname", "Delos Cruz");
			request.getSession().setAttribute("email", "pishbolkikiam@yahoo.com");
			request.getSession().setAttribute("imgpath",un+"\\");
			Cookie cookie = new Cookie("uname", un);
			cookie.setMaxAge(60*60*24*365*2);
			response.addCookie(cookie);
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}
		else{
			response.sendRedirect("Incorrect.jsp");
			
		}
		
		
		
		//doGet(request, response);
	}

}
