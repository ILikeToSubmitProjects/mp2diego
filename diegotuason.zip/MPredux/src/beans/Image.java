package beans;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Session Bean implementation class Image
 */

public class Image {

    /**
     * Default constructor. 
     * 
     * 
     */

	private Boolean privacy;
	private String name;
	private String tags;
	
	
    public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Image(String name, String tags, Boolean privacy) {
		super();
		this.privacy = privacy;
		this.name = name;
	}



	public Boolean getPrivacy() {
		return privacy;
	}

	public void setPrivacy(Boolean privacy) {
		this.privacy = privacy;
	}
}
