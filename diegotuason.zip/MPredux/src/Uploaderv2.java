

import java.io.*;
import beans.Image;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileItemFactory;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;

/**
 * Servlet implementation class Uploader
 */
@WebServlet("/Uploaderv2")
public class Uploaderv2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Uploaderv2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw = response.getWriter();
		List<Image> myImgs = (List<Image>)request.getSession().getAttribute("mypics");
		
		if(!ServletFileUpload.isMultipartContent(request)){
			pw.println("Nothing to upload.");
			return;
		}
		
		FileItemFactory fif = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(fif);
		File file = new File("");

		try{
			List<FileItem> imgs = upload.parseRequest(new ServletRequestContext(request));
			for(FileItem item:imgs){
				
				String contentType = item.getContentType();
				if(!(contentType.equals("image/png")||contentType.equals("image/jpg")||contentType.equals("image/gif"))){
					pw.print("Invalid format.");
					continue;
				}
				File dir = new File(request.getServletContext().getRealPath(request.getSession().getAttribute("uname").toString()));
				if(contentType.equals("image/png")){
					file = File.createTempFile("img",".png",dir);	
					item.write(file);
				}
				else if(contentType.equals("image/jpg")){
					file = File.createTempFile("img",".jpg",dir);
					item.write(file);
				}
				else if(contentType.equals("image/gif")){
					file = File.createTempFile("img",".gif",dir);
					item.write(file);
			}	
			Image img = new Image(file.getName(),"sample",false);
			request.getSession().setAttribute("tagimg",img);
			response.sendRedirect("Options.jsp");
			}
			
			
		}
		catch(FileUploadException e){
			pw.print("Upload failed.");
			
		}
		catch(Exception ex){
			pw.print("Error.");
		}
		
		
		
		
		
	}

}
